(function() {
	'use strict';

	angular.module('angularMiniProject.accomplishments', []);
})();