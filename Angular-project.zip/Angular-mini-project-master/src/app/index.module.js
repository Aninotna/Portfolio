(function() {
  'use strict';

  angular
    .module('angularMiniProject', ['ngAnimate', 'ui.router', 'toastr', 'angularMiniProject.accomplishments', 'angularMiniProject.login', 'angularMiniProject.accomplishments.create']);

})();
