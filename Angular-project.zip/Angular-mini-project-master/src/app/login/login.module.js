(function() {
	'use strict';

	angular.module('angularMiniProject.login', []);
})();